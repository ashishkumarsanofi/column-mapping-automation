# Advanced Column Mapping Tool

## 🚀 Quick Start

1. **Double-click:** `START_MAPPING_TOOL.bat`
2. **Wait** for your browser to open
3. **Start using** the tool in your browser
4. **To stop:** Close the console window or run `STOP_APP.bat`

## 📋 Requirements

- Windows 10/11
- Python 3.7+ installed
- Web browser (Chrome, Edge, Firefox)

---

**That's it! Just click START_MAPPING_TOOL.bat to begin!** 🎯
